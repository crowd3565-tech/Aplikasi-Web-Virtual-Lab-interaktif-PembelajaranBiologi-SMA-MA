.class public Lid/unimed/labdnatomat/TtsProg;
.super Landroid/speech/tts/UtteranceProgressListener;
.source "TtsProg.java"

.field public a:Lid/unimed/labdnatomat/MainActivity;

.method public constructor <init>(Lid/unimed/labdnatomat/MainActivity;)V
    .locals 0
    invoke-direct {p0}, Landroid/speech/tts/UtteranceProgressListener;-><init>()V
    iput-object p1, p0, Lid/unimed/labdnatomat/TtsProg;->a:Lid/unimed/labdnatomat/MainActivity;
    return-void
.end method

.method public onStart(Ljava/lang/String;)V
    .locals 0
    return-void
.end method

.method public onDone(Ljava/lang/String;)V
    .locals 2
    new-instance v0, Lid/unimed/labdnatomat/TtsDone;
    iget-object v1, p0, Lid/unimed/labdnatomat/TtsProg;->a:Lid/unimed/labdnatomat/MainActivity;
    invoke-direct {v0, v1, p1}, Lid/unimed/labdnatomat/TtsDone;-><init>(Lid/unimed/labdnatomat/MainActivity;Ljava/lang/String;)V
    invoke-virtual {v1, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    return-void
.end method

.method public onError(Ljava/lang/String;)V
    .locals 0
    invoke-virtual {p0, p1}, Lid/unimed/labdnatomat/TtsProg;->onDone(Ljava/lang/String;)V
    return-void
.end method
