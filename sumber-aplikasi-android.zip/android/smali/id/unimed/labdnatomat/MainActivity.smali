.class public Lid/unimed/labdnatomat/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"

# Aplikasi Android pembungkus: menampilkan web Lab Virtual Isolasi DNA Tomat (assets/www) di WebView,
# menyimpan data di penyimpanan lokal WebView, dan menyediakan suara narasi lewat Text-to-Speech Android.

.field public wv:Landroid/webkit/WebView;
.field public tts:Landroid/speech/tts/TextToSpeech;

.method public constructor <init>()V
    .locals 0
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    new-instance v0, Landroid/webkit/WebView;
    invoke-direct {v0, p0}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
    iput-object v0, p0, Lid/unimed/labdnatomat/MainActivity;->wv:Landroid/webkit/WebView;

    const v1, -0x362d27
    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->setBackgroundColor(I)V

    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    move-result-object v1
    const/4 v2, 0x1
    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V
    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V
    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setDatabaseEnabled(Z)V
    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V
    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setAllowFileAccessFromFileURLs(Z)V
    const/4 v3, 0x0
    invoke-virtual {v1, v3}, Landroid/webkit/WebSettings;->setMediaPlaybackRequiresUserGesture(Z)V

    new-instance v3, Landroid/webkit/WebViewClient;
    invoke-direct {v3}, Landroid/webkit/WebViewClient;-><init>()V
    invoke-virtual {v0, v3}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V
    new-instance v3, Landroid/webkit/WebChromeClient;
    invoke-direct {v3}, Landroid/webkit/WebChromeClient;-><init>()V
    invoke-virtual {v0, v3}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    new-instance v3, Lid/unimed/labdnatomat/TtsInit;
    invoke-direct {v3, p0}, Lid/unimed/labdnatomat/TtsInit;-><init>(Lid/unimed/labdnatomat/MainActivity;)V
    new-instance v4, Landroid/speech/tts/TextToSpeech;
    invoke-direct {v4, p0, v3}, Landroid/speech/tts/TextToSpeech;-><init>(Landroid/content/Context;Landroid/speech/tts/TextToSpeech$OnInitListener;)V
    iput-object v4, p0, Lid/unimed/labdnatomat/MainActivity;->tts:Landroid/speech/tts/TextToSpeech;

    new-instance v3, Lid/unimed/labdnatomat/TtsBridge;
    invoke-direct {v3, p0}, Lid/unimed/labdnatomat/TtsBridge;-><init>(Lid/unimed/labdnatomat/MainActivity;)V
    const-string v4, "AndroidTTS"
    invoke-virtual {v0, v3, v4}, Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "file:///android_asset/www/index.html"
    invoke-virtual {v0, v3}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    invoke-virtual {p0, v0}, Lid/unimed/labdnatomat/MainActivity;->setContentView(Landroid/view/View;)V
    return-void
.end method

.method protected onPause()V
    .locals 1
    iget-object v0, p0, Lid/unimed/labdnatomat/MainActivity;->tts:Landroid/speech/tts/TextToSpeech;
    if-eqz v0, :skip
    invoke-virtual {v0}, Landroid/speech/tts/TextToSpeech;->stop()I
    :skip
    invoke-super {p0}, Landroid/app/Activity;->onPause()V
    return-void
.end method

.method protected onDestroy()V
    .locals 1
    iget-object v0, p0, Lid/unimed/labdnatomat/MainActivity;->tts:Landroid/speech/tts/TextToSpeech;
    if-eqz v0, :skip
    invoke-virtual {v0}, Landroid/speech/tts/TextToSpeech;->shutdown()V
    :skip
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V
    return-void
.end method

.method public onBackPressed()V
    .locals 1
    iget-object v0, p0, Lid/unimed/labdnatomat/MainActivity;->wv:Landroid/webkit/WebView;
    if-eqz v0, :exit
    invoke-virtual {v0}, Landroid/webkit/WebView;->canGoBack()Z
    move-result v0
    if-eqz v0, :exit
    iget-object v0, p0, Lid/unimed/labdnatomat/MainActivity;->wv:Landroid/webkit/WebView;
    invoke-virtual {v0}, Landroid/webkit/WebView;->goBack()V
    return-void
    :exit
    invoke-super {p0}, Landroid/app/Activity;->onBackPressed()V
    return-void
.end method
