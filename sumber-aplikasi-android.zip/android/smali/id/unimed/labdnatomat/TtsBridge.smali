.class public Lid/unimed/labdnatomat/TtsBridge;
.super Ljava/lang/Object;
.source "TtsBridge.java"

.field public a:Lid/unimed/labdnatomat/MainActivity;

.method public constructor <init>(Lid/unimed/labdnatomat/MainActivity;)V
    .locals 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput-object p1, p0, Lid/unimed/labdnatomat/TtsBridge;->a:Lid/unimed/labdnatomat/MainActivity;
    return-void
.end method

.method public speak(Ljava/lang/String;Ljava/lang/String;FF)V
    .locals 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation
    iget-object v0, p0, Lid/unimed/labdnatomat/TtsBridge;->a:Lid/unimed/labdnatomat/MainActivity;
    iget-object v0, v0, Lid/unimed/labdnatomat/MainActivity;->tts:Landroid/speech/tts/TextToSpeech;
    if-eqz v0, :done
    invoke-virtual {v0, p3}, Landroid/speech/tts/TextToSpeech;->setSpeechRate(F)I
    invoke-virtual {v0, p4}, Landroid/speech/tts/TextToSpeech;->setPitch(F)I
    const/4 v1, 0x0
    const/4 v2, 0x0
    invoke-virtual {v0, p1, v1, v2, p2}, Landroid/speech/tts/TextToSpeech;->speak(Ljava/lang/CharSequence;ILandroid/os/Bundle;Ljava/lang/String;)I
    :done
    return-void
.end method

.method public stop()V
    .locals 1
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation
    iget-object v0, p0, Lid/unimed/labdnatomat/TtsBridge;->a:Lid/unimed/labdnatomat/MainActivity;
    iget-object v0, v0, Lid/unimed/labdnatomat/MainActivity;->tts:Landroid/speech/tts/TextToSpeech;
    if-eqz v0, :done
    invoke-virtual {v0}, Landroid/speech/tts/TextToSpeech;->stop()I
    :done
    return-void
.end method
