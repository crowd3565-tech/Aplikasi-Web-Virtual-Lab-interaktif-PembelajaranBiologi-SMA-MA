.class public Lid/unimed/labdnatomat/TtsInit;
.super Ljava/lang/Object;
.source "TtsInit.java"
.implements Landroid/speech/tts/TextToSpeech$OnInitListener;

.field public a:Lid/unimed/labdnatomat/MainActivity;

.method public constructor <init>(Lid/unimed/labdnatomat/MainActivity;)V
    .locals 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput-object p1, p0, Lid/unimed/labdnatomat/TtsInit;->a:Lid/unimed/labdnatomat/MainActivity;
    return-void
.end method

.method public onInit(I)V
    .locals 4
    if-nez p1, :done
    iget-object v0, p0, Lid/unimed/labdnatomat/TtsInit;->a:Lid/unimed/labdnatomat/MainActivity;
    iget-object v0, v0, Lid/unimed/labdnatomat/MainActivity;->tts:Landroid/speech/tts/TextToSpeech;
    if-eqz v0, :done
    new-instance v1, Ljava/util/Locale;
    const-string v2, "id"
    const-string v3, "ID"
    invoke-direct {v1, v2, v3}, Ljava/util/Locale;-><init>(Ljava/lang/String;Ljava/lang/String;)V
    invoke-virtual {v0, v1}, Landroid/speech/tts/TextToSpeech;->setLanguage(Ljava/util/Locale;)I
    new-instance v1, Lid/unimed/labdnatomat/TtsProg;
    iget-object v2, p0, Lid/unimed/labdnatomat/TtsInit;->a:Lid/unimed/labdnatomat/MainActivity;
    invoke-direct {v1, v2}, Lid/unimed/labdnatomat/TtsProg;-><init>(Lid/unimed/labdnatomat/MainActivity;)V
    invoke-virtual {v0, v1}, Landroid/speech/tts/TextToSpeech;->setOnUtteranceProgressListener(Landroid/speech/tts/UtteranceProgressListener;)I
    :done
    return-void
.end method
