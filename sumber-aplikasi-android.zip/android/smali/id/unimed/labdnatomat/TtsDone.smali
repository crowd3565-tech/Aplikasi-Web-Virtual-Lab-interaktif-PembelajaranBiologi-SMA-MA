.class public Lid/unimed/labdnatomat/TtsDone;
.super Ljava/lang/Object;
.source "TtsDone.java"
.implements Ljava/lang/Runnable;

.field public a:Lid/unimed/labdnatomat/MainActivity;
.field public id:Ljava/lang/String;

.method public constructor <init>(Lid/unimed/labdnatomat/MainActivity;Ljava/lang/String;)V
    .locals 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput-object p1, p0, Lid/unimed/labdnatomat/TtsDone;->a:Lid/unimed/labdnatomat/MainActivity;
    iput-object p2, p0, Lid/unimed/labdnatomat/TtsDone;->id:Ljava/lang/String;
    return-void
.end method

.method public run()V
    .locals 3
    iget-object v1, p0, Lid/unimed/labdnatomat/TtsDone;->a:Lid/unimed/labdnatomat/MainActivity;
    iget-object v1, v1, Lid/unimed/labdnatomat/MainActivity;->wv:Landroid/webkit/WebView;
    if-eqz v1, :done
    new-instance v0, Ljava/lang/StringBuilder;
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V
    const-string v2, "window.__ttsDone&&window.__ttsDone('"
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    iget-object v2, p0, Lid/unimed/labdnatomat/TtsDone;->id:Ljava/lang/String;
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    const-string v2, "')"
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v0
    const/4 v2, 0x0
    invoke-virtual {v1, v0, v2}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    :done
    return-void
.end method
