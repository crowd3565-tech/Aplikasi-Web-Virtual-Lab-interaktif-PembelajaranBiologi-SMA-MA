import com.android.apksig.ApkSigner;
import com.android.apksig.ApkVerifier;
import java.io.File;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.Collections;
import java.util.List;

/** Menandatangani APK (skema v1 + v2) lalu memverifikasinya. */
public class Signer {
  public static void main(String[] a) throws Exception {
    String in = a[0], out = a[1], ks = a[2], pass = a[3], alias = a[4];
    KeyStore k = KeyStore.getInstance("PKCS12");
    try (FileInputStream f = new FileInputStream(ks)) { k.load(f, pass.toCharArray()); }
    PrivateKey key = (PrivateKey) k.getKey(alias, pass.toCharArray());
    X509Certificate cert = (X509Certificate) k.getCertificate(alias);
    List<X509Certificate> chain = Collections.singletonList(cert);
    ApkSigner.SignerConfig sc = new ApkSigner.SignerConfig.Builder("LABDNA", key, chain).build();
    new ApkSigner.Builder(Collections.singletonList(sc)).setInputApk(new File(in)).setOutputApk(new File(out))
        .setMinSdkVersion(24).setV1SigningEnabled(false).setV2SigningEnabled(true).setCreatedBy("Lab DNA Tomat").build().sign();
    ApkVerifier.Result r = new ApkVerifier.Builder(new File(out)).build().verify();
    System.out.println("verified=" + r.isVerified() + " v1=" + r.isVerifiedUsingV1Scheme() + " v2=" + r.isVerifiedUsingV2Scheme());
    for (ApkVerifier.IssueWithParams e : r.getErrors()) System.out.println("ERROR " + e);
    for (ApkVerifier.IssueWithParams w : r.getWarnings()) System.out.println("WARN " + w);
  }
}
