"""Merakit APK tanpa Android SDK: manifest biner (AXML), resources.arsc berisi satu ikon,
classes.dex hasil smali, dan aset web di assets/www. Entri STORED diselaraskan 4 byte."""
import struct, zipfile, os, sys

WEB = '/home/user/vlab-tomat'
B = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(B, 'unsigned.apk')
PKG = 'id.unimed.labdnatomat'
VERSION_CODE, VERSION_NAME = 3, '1.2'
LABEL = 'Lab DNA Tomat'
ICON_ID = 0x7f010000

ANDROID_NS = 'http://schemas.android.com/apk/res/android'
ATTR = {'theme': 0x01010000, 'label': 0x01010001, 'icon': 0x01010002, 'name': 0x01010003, 'exported': 0x01010010,
        'screenOrientation': 0x0101001e, 'configChanges': 0x0101001f, 'minSdkVersion': 0x0101020c, 'versionCode': 0x0101021b,
        'versionName': 0x0101021c, 'targetSdkVersion': 0x01010270, 'allowBackup': 0x01010280, 'hardwareAccelerated': 0x010102d3,
        'windowSoftInputMode': 0x0101022b, 'largeHeap': 0x0101035a, 'usesCleartextTraffic': 0x010104ec}
T_REF, T_STR, T_DEC, T_HEX, T_BOOL = 0x01, 0x03, 0x10, 0x11, 0x12

# (tag, [(ns_is_android, name, type, value)], children)
manifest = ('manifest', [(False, 'package', T_STR, PKG), (True, 'versionCode', T_DEC, VERSION_CODE), (True, 'versionName', T_STR, VERSION_NAME)], [
    ('uses-sdk', [(True, 'minSdkVersion', T_DEC, 24), (True, 'targetSdkVersion', T_DEC, 34)], []),
    ('uses-permission', [(True, 'name', T_STR, 'android.permission.INTERNET')], []),
    ('queries', [], [('intent', [], [('action', [(True, 'name', T_STR, 'android.intent.action.TTS_SERVICE')], [])])]),
    ('application', [(True, 'label', T_STR, LABEL), (True, 'icon', T_REF, ICON_ID), (True, 'theme', T_REF, 0x01030241),
                     (True, 'allowBackup', T_BOOL, True), (True, 'hardwareAccelerated', T_BOOL, True), (True, 'largeHeap', T_BOOL, True),
                     (True, 'usesCleartextTraffic', T_BOOL, False)], [
        ('activity', [(True, 'name', T_STR, PKG + '.MainActivity'), (True, 'exported', T_BOOL, True), (True, 'label', T_STR, LABEL),
                      (True, 'configChanges', T_HEX, 0x0DA0 | 0x0080 | 0x0020), (True, 'windowSoftInputMode', T_HEX, 0x10),
                      (True, 'hardwareAccelerated', T_BOOL, True)], [
            ('intent-filter', [], [
                ('action', [(True, 'name', T_STR, 'android.intent.action.MAIN')], []),
                ('category', [(True, 'name', T_STR, 'android.intent.category.LAUNCHER')], [])])])])])

def pad4(b): return b + b'\0' * (-len(b) % 4)

def string_pool(strings):
    offs, data = [], b''
    for s in strings:
        offs.append(len(data)); e = s.encode('utf-16-le'); data += struct.pack('<H', len(s)) + e + b'\0\0'
    data = pad4(data)
    hdr = 28; start = hdr + 4 * len(strings)
    body = b''.join(struct.pack('<I', o) for o in offs) + data
    return struct.pack('<HHIIIIII', 0x0001, hdr, hdr + len(body), len(strings), 0, 0, start, 0) + body

def build_axml():
    # kumpulkan atribut android (urut menurut ID) agar resource map sejajar dengan awal string pool
    names = set()
    def walk(n):
        for a in n[1]:
            if a[0]: names.add(a[1])
        for c in n[2]: walk(c)
    walk(manifest)
    attr_names = sorted(names, key=lambda k: ATTR[k])
    strings = list(attr_names)
    def si(s):
        if s not in strings: strings.append(s)
        return strings.index(s)
    for s in ['android', ANDROID_NS]: si(s)
    body = []
    def elem(n):
        tag, attrs, kids = n
        rec = []
        for is_and, name, typ, val in sorted(attrs, key=lambda a: (0, ATTR[a[1]]) if a[0] else (1, 0)):
            ns = si(ANDROID_NS) if is_and else 0xFFFFFFFF
            nm = si(name)
            if typ == T_STR: raw = si(val); data = raw
            elif typ == T_BOOL: raw = 0xFFFFFFFF; data = 0xFFFFFFFF if val else 0
            else: raw = 0xFFFFFFFF; data = val
            rec.append(struct.pack('<IIIHBBI', ns, nm, raw, 8, 0, typ, data))
        ext = struct.pack('<IIHHHHHH', 0xFFFFFFFF, si(tag), 20, 20, len(rec), 0, 0, 0) + b''.join(rec)
        body.append(struct.pack('<HHIII', 0x0102, 16, 16 + len(ext), 1, 0xFFFFFFFF) + ext)
        for k in kids: elem(k)
        body.append(struct.pack('<HHIIIII', 0x0103, 16, 24, 1, 0xFFFFFFFF, 0xFFFFFFFF, si(tag)))
    elem(manifest)
    ns_start = struct.pack('<HHIIIII', 0x0100, 16, 24, 1, 0xFFFFFFFF, si('android'), si(ANDROID_NS))
    ns_end = struct.pack('<HHIIIII', 0x0101, 16, 24, 1, 0xFFFFFFFF, si('android'), si(ANDROID_NS))
    sp = string_pool(strings)
    rmap = struct.pack('<HHI', 0x0180, 8, 8 + 4 * len(attr_names)) + b''.join(struct.pack('<I', ATTR[k]) for k in attr_names)
    content = sp + rmap + ns_start + b''.join(body) + ns_end
    return struct.pack('<HHI', 0x0003, 8, 8 + len(content)) + content

def build_arsc(icon_path):
    gsp = string_pool([icon_path])
    tsp = string_pool(['drawable'])
    ksp = string_pool(['ic_launcher'])
    spec = struct.pack('<HHIBBHI', 0x0202, 16, 16 + 4, 1, 0, 0, 1) + struct.pack('<I', 0)
    config = struct.pack('<I', 64) + b'\0' * 60
    t_hdr = 20 + len(config)
    entry = struct.pack('<HHI', 8, 0, 0) + struct.pack('<HBBI', 8, 0, T_STR, 0)
    entries_start = t_hdr + 4
    ttype = struct.pack('<HHIBBHII', 0x0201, t_hdr, entries_start + len(entry), 1, 0, 0, 1, entries_start) + config + struct.pack('<I', 0) + entry
    name = 'id.unimed.labdnatomat'.encode('utf-16-le').ljust(256, b'\0')
    p_hdr = 288
    type_off = p_hdr; key_off = p_hdr + len(tsp)
    pkg_body = tsp + ksp + spec + ttype
    pkg = struct.pack('<HHII', 0x0200, p_hdr, p_hdr + len(pkg_body), 0x7f) + name + struct.pack('<IIIII', type_off, 1, key_off, 1, 0) + pkg_body
    content = gsp + pkg
    return struct.pack('<HHII', 0x0002, 12, 12 + len(content), 1) + content

WEB_FILES = ['index.html', 'style.css', 'realism.css', 'script.js', 'realism.js', 'microscope.js', 'manifest.webmanifest',
             'icons/icon-192.png', 'icons/icon-512.png', 'icons/apple-touch-icon.png', 'audio/rekaman.json']

def add(z, name, data, store):
    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 27, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_STORED if store else zipfile.ZIP_DEFLATED
    zi.external_attr = 0o644 << 16
    if store:
        off = z.fp.tell() + 30 + len(name.encode())
        padn = (-(off + 6)) % 4  # 4 byte header ekstra + 2 byte keselarasan + padding
        zi.extra = struct.pack('<HH', 0xD935, 2 + padn) + struct.pack('<H', 4) + b'\0' * padn
    z.writestr(zi, data)

ICON_PATH = 'res/drawable/ic_launcher.png'
if os.path.exists(OUT): os.remove(OUT)
with zipfile.ZipFile(OUT, 'w') as z:
    add(z, 'AndroidManifest.xml', build_axml(), False)
    add(z, 'resources.arsc', build_arsc(ICON_PATH), True)
    add(z, 'classes.dex', open(os.path.join(B, 'classes.dex'), 'rb').read(), False)
    add(z, ICON_PATH, open(os.path.join(WEB, 'icons/icon-192.png'), 'rb').read(), True)
    for f in WEB_FILES:
        p = os.path.join(WEB, f)
        add(z, 'assets/www/' + f, open(p, 'rb').read(), f.endswith('.png'))
print('unsigned apk', os.path.getsize(OUT))
